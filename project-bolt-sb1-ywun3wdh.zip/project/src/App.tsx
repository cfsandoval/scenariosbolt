import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Dashboard from './components/pages/Dashboard';
import ScenarioWizard from './components/pages/ScenarioWizard';
import ScenarioList from './components/pages/ScenarioList';
import ScenarioComparison from './components/pages/ScenarioComparison';
import MonitoringDashboard from './components/pages/MonitoringDashboard';
import TeamCollaboration from './components/pages/TeamCollaboration';
import { ScenarioProvider } from './context/ScenarioContext';
import { TeamProvider } from './context/TeamContext';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <ScenarioProvider>
      <TeamProvider>
        <Router>
          <div className="flex h-screen bg-gray-50">
            <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />
            
            <div className="flex-1 flex flex-col overflow-hidden">
              <Header setSidebarOpen={setSidebarOpen} />
              
              <main className="flex-1 overflow-auto">
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/scenarios" element={<ScenarioList />} />
                  <Route path="/create-scenario" element={<ScenarioWizard />} />
                  <Route path="/edit-scenario/:id" element={<ScenarioWizard />} />
                  <Route path="/compare" element={<ScenarioComparison />} />
                  <Route path="/monitoring" element={<MonitoringDashboard />} />
                  <Route path="/collaboration" element={<TeamCollaboration />} />
                </Routes>
              </main>
            </div>
          </div>
        </Router>
      </TeamProvider>
    </ScenarioProvider>
  );
}

export default App;