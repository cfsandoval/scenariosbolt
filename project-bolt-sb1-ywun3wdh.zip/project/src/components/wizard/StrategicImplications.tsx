import React, { useState } from 'react';
import { Plus, Trash2, Target, Shield, Lightbulb, Info } from 'lucide-react';
import { Scenario } from '../../context/ScenarioContext';

interface StrategicImplicationsProps {
  scenario: Partial<Scenario>;
  setScenario: (scenario: Partial<Scenario>) => void;
}

const StrategicImplications: React.FC<StrategicImplicationsProps> = ({ scenario, setScenario }) => {
  const [newOpportunity, setNewOpportunity] = useState('');
  const [newThreat, setNewThreat] = useState('');
  const [newRecommendation, setNewRecommendation] = useState('');

  const handleAddOpportunity = () => {
    if (!newOpportunity.trim()) return;
    
    const updatedImplications = {
      ...scenario.strategicImplications,
      opportunities: [...(scenario.strategicImplications?.opportunities || []), newOpportunity.trim()]
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });

    setNewOpportunity('');
  };

  const handleAddThreat = () => {
    if (!newThreat.trim()) return;
    
    const updatedImplications = {
      ...scenario.strategicImplications,
      threats: [...(scenario.strategicImplications?.threats || []), newThreat.trim()]
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });

    setNewThreat('');
  };

  const handleAddRecommendation = () => {
    if (!newRecommendation.trim()) return;
    
    const updatedImplications = {
      ...scenario.strategicImplications,
      recommendations: [...(scenario.strategicImplications?.recommendations || []), newRecommendation.trim()]
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });

    setNewRecommendation('');
  };

  const handleRemoveOpportunity = (index: number) => {
    const updatedImplications = {
      ...scenario.strategicImplications,
      opportunities: scenario.strategicImplications?.opportunities?.filter((_, i) => i !== index) || []
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });
  };

  const handleRemoveThreat = (index: number) => {
    const updatedImplications = {
      ...scenario.strategicImplications,
      threats: scenario.strategicImplications?.threats?.filter((_, i) => i !== index) || []
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });
  };

  const handleRemoveRecommendation = (index: number) => {
    const updatedImplications = {
      ...scenario.strategicImplications,
      recommendations: scenario.strategicImplications?.recommendations?.filter((_, i) => i !== index) || []
    };

    setScenario({
      ...scenario,
      strategicImplications: updatedImplications
    });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Strategic Implications Analysis</h2>
        <p className="text-gray-600">
          Analyze the strategic implications of your scenarios by identifying opportunities, threats, 
          and actionable recommendations. This step transforms scenario insights into strategic guidance.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-blue-900 mb-1">Strategic Analysis Framework</h3>
            <p className="text-sm text-blue-700">
              Consider each scenario's implications across all your narratives. Look for patterns, 
              common themes, and strategic options that remain robust across multiple scenarios. 
              Focus on actionable insights that can inform decision-making today.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {/* Opportunities */}
        <div>
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
              <Target className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Strategic Opportunities</h3>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex space-x-3 mb-4">
              <input
                type="text"
                value={newOpportunity}
                onChange={(e) => setNewOpportunity(e.target.value)}
                placeholder="Identify a strategic opportunity emerging from your scenarios..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                onKeyPress={(e) => e.key === 'Enter' && handleAddOpportunity()}
              />
              <button
                onClick={handleAddOpportunity}
                disabled={!newOpportunity.trim()}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {scenario.strategicImplications?.opportunities?.length === 0 ? (
                <p className="text-gray-500 text-sm italic">No opportunities identified yet</p>
              ) : (
                scenario.strategicImplications?.opportunities?.map((opportunity, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-900 flex-1">{opportunity}</p>
                    <button
                      onClick={() => handleRemoveOpportunity(index)}
                      className="ml-3 p-1 text-green-400 hover:text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Threats */}
        <div>
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center mr-3">
              <Shield className="w-5 h-5 text-red-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Strategic Threats</h3>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex space-x-3 mb-4">
              <input
                type="text"
                value={newThreat}
                onChange={(e) => setNewThreat(e.target.value)}
                placeholder="Identify a strategic threat or risk emerging from your scenarios..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                onKeyPress={(e) => e.key === 'Enter' && handleAddThreat()}
              />
              <button
                onClick={handleAddThreat}
                disabled={!newThreat.trim()}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {scenario.strategicImplications?.threats?.length === 0 ? (
                <p className="text-gray-500 text-sm italic">No threats identified yet</p>
              ) : (
                scenario.strategicImplications?.threats?.map((threat, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-900 flex-1">{threat}</p>
                    <button
                      onClick={() => handleRemoveThreat(index)}
                      className="ml-3 p-1 text-red-400 hover:text-red-600 hover:bg-red-100 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div>
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
              <Lightbulb className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">Strategic Recommendations</h3>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex space-x-3 mb-4">
              <input
                type="text"
                value={newRecommendation}
                onChange={(e) => setNewRecommendation(e.target.value)}
                placeholder="Provide an actionable strategic recommendation based on your analysis..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                onKeyPress={(e) => e.key === 'Enter' && handleAddRecommendation()}
              />
              <button
                onClick={handleAddRecommendation}
                disabled={!newRecommendation.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {scenario.strategicImplications?.recommendations?.length === 0 ? (
                <p className="text-gray-500 text-sm italic">No recommendations provided yet</p>
              ) : (
                scenario.strategicImplications?.recommendations?.map((recommendation, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-900 flex-1">{recommendation}</p>
                    <button
                      onClick={() => handleRemoveRecommendation(index)}
                      className="ml-3 p-1 text-blue-400 hover:text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h4 className="font-medium text-gray-900 mb-4">Strategic Analysis Summary</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {scenario.strategicImplications?.opportunities?.length || 0}
              </div>
              <div className="text-sm text-gray-600">Opportunities</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {scenario.strategicImplications?.threats?.length || 0}
              </div>
              <div className="text-sm text-gray-600">Threats</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {scenario.strategicImplications?.recommendations?.length || 0}
              </div>
              <div className="text-sm text-gray-600">Recommendations</div>
            </div>
          </div>

          <div className="text-sm text-gray-600">
            <p>
              Review your analysis to ensure it captures the key strategic insights from your scenarios. 
              Consider how these implications might inform your organization's strategy, risk management, 
              and innovation priorities.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StrategicImplications;