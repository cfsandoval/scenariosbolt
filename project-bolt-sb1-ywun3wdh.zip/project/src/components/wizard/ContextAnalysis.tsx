import React from 'react';
import { Info } from 'lucide-react';
import { Scenario } from '../../context/ScenarioContext';

interface ContextAnalysisProps {
  scenario: Partial<Scenario>;
  setScenario: (scenario: Partial<Scenario>) => void;
}

const ContextAnalysis: React.FC<ContextAnalysisProps> = ({ scenario, setScenario }) => {
  const updateContext = (field: string, value: string) => {
    setScenario({
      ...scenario,
      context: {
        ...scenario.context!,
        [field]: value
      }
    });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Context Analysis</h2>
        <p className="text-gray-600">
          Define the context and scope of your scenario planning exercise. This foundational step establishes 
          the framework for identifying critical uncertainties and driving questions.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-blue-900 mb-1">Ramirez-Ravetz Methodology</h3>
            <p className="text-sm text-blue-700">
              Start with a clear definition of your context. Consider the temporal and geographical boundaries, 
              key stakeholders, and the central question driving your scenario exploration.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Scenario Name and Description */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Scenario Name *
            </label>
            <input
              type="text"
              value={scenario.name || ''}
              onChange={(e) => setScenario({ ...scenario, name: e.target.value })}
              placeholder="e.g., Future of Renewable Energy 2035"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Context Title *
            </label>
            <input
              type="text"
              value={scenario.context?.title || ''}
              onChange={(e) => updateContext('title', e.target.value)}
              placeholder="Brief title for this context"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Scenario Description
          </label>
          <textarea
            value={scenario.description || ''}
            onChange={(e) => setScenario({ ...scenario, description: e.target.value })}
            rows={3}
            placeholder="Provide a brief overview of what this scenario planning exercise aims to explore..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Context Description *
          </label>
          <textarea
            value={scenario.context?.description || ''}
            onChange={(e) => updateContext('description', e.target.value)}
            rows={4}
            placeholder="Describe the current situation, background, and key factors that define this context..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Time Horizon *
            </label>
            <select
              value={scenario.context?.timeHorizon || ''}
              onChange={(e) => updateContext('timeHorizon', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select time horizon</option>
              <option value="1-2 years">1-2 years (Short-term)</option>
              <option value="3-5 years">3-5 years (Medium-term)</option>
              <option value="5-10 years">5-10 years (Long-term)</option>
              <option value="10+ years">10+ years (Very long-term)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Geographic Scope *
            </label>
            <select
              value={scenario.context?.geographicScope || ''}
              onChange={(e) => updateContext('geographicScope', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select geographic scope</option>
              <option value="Local">Local</option>
              <option value="Regional">Regional</option>
              <option value="National">National</option>
              <option value="International">International</option>
              <option value="Global">Global</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Key Question *
          </label>
          <textarea
            value={scenario.context?.keyQuestion || ''}
            onChange={(e) => updateContext('keyQuestion', e.target.value)}
            rows={3}
            placeholder="What is the central question this scenario planning exercise seeks to address? e.g., 'How might climate policies evolve over the next decade and what impact will they have on our industry?'"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>
    </div>
  );
};

export default ContextAnalysis;