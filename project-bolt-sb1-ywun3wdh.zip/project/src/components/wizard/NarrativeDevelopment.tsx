import React, { useState } from 'react';
import { Plus, Edit2, Trash2, FileText, Info } from 'lucide-react';
import { Scenario } from '../../context/ScenarioContext';

interface NarrativeDevelopmentProps {
  scenario: Partial<Scenario>;
  setScenario: (scenario: Partial<Scenario>) => void;
}

const NarrativeDevelopment: React.FC<NarrativeDevelopmentProps> = ({ scenario, setScenario }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingNarrative, setEditingNarrative] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    archetype: '',
    probability: 25
  });

  const scenarioArchetypes = [
    'Optimistic Growth',
    'Cautious Progress',
    'Stagnation',
    'Decline',
    'Transformation',
    'Disruption',
    'Status Quo',
    'Crisis Response'
  ];

  const handleAddNarrative = () => {
    const newNarrative = {
      id: `narrative-${Date.now()}`,
      ...formData
    };

    setScenario({
      ...scenario,
      narratives: [...(scenario.narratives || []), newNarrative]
    });

    setFormData({ title: '', content: '', archetype: '', probability: 25 });
    setShowAddForm(false);
  };

  const handleEditNarrative = (narrative: any) => {
    setEditingNarrative(narrative);
    setFormData({
      title: narrative.title,
      content: narrative.content,
      archetype: narrative.archetype,
      probability: narrative.probability
    });
    setShowAddForm(true);
  };

  const handleUpdateNarrative = () => {
    if (!editingNarrative) return;

    const updatedNarratives = scenario.narratives?.map(n =>
      n.id === editingNarrative.id ? { ...n, ...formData } : n
    ) || [];

    setScenario({
      ...scenario,
      narratives: updatedNarratives
    });

    setFormData({ title: '', content: '', archetype: '', probability: 25 });
    setShowAddForm(false);
    setEditingNarrative(null);
  };

  const handleDeleteNarrative = (id: string) => {
    setScenario({
      ...scenario,
      narratives: scenario.narratives?.filter(n => n.id !== id) || []
    });
  };

  const getArchetypeColor = (archetype: string) => {
    const colorMap: { [key: string]: string } = {
      'Optimistic Growth': 'bg-green-100 text-green-800',
      'Cautious Progress': 'bg-blue-100 text-blue-800',
      'Stagnation': 'bg-gray-100 text-gray-800',
      'Decline': 'bg-red-100 text-red-800',
      'Transformation': 'bg-purple-100 text-purple-800',
      'Disruption': 'bg-orange-100 text-orange-800',
      'Status Quo': 'bg-yellow-100 text-yellow-800',
      'Crisis Response': 'bg-pink-100 text-pink-800'
    };
    return colorMap[archetype] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Scenario Narrative Development</h2>
        <p className="text-gray-600">
          Create compelling, plausible narratives for each scenario archetype. These stories should bring 
          your uncertainty axes to life through detailed, realistic accounts of how the future might unfold.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-blue-900 mb-1">Writing Effective Scenario Narratives</h3>
            <p className="text-sm text-blue-700">
              Good scenarios are not predictions but plausible stories. Focus on causality, include specific 
              details, consider multiple perspectives, and ensure internal consistency. Each narrative should 
              clearly reflect the position on your uncertainty axes.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Add Narrative Form */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">Scenario Narratives</h3>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Narrative
          </button>
        </div>

        {showAddForm && (
          <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
            <h4 className="font-medium text-gray-900 mb-4">
              {editingNarrative ? 'Edit Scenario Narrative' : 'Create New Scenario Narrative'}
            </h4>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Scenario Title *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., 'Green Transformation 2030'"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Scenario Archetype
                  </label>
                  <select
                    value={formData.archetype}
                    onChange={(e) => setFormData({ ...formData, archetype: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select archetype</option>
                    {scenarioArchetypes.map(archetype => (
                      <option key={archetype} value={archetype}>{archetype}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Probability Assessment (%)
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={formData.probability}
                  onChange={(e) => setFormData({ ...formData, probability: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>0%</span>
                  <span className="font-medium">{formData.probability}%</span>
                  <span>100%</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Scenario Narrative *
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={8}
                  placeholder="Write a detailed, plausible narrative describing how this scenario unfolds. Include specific events, actors, and consequences. Consider:

- What key events trigger this scenario?
- How do stakeholders react and adapt?
- What are the major milestones along the way?
- What does the end state look like?
- What are the implications for different actors?

Example: 'In 2025, a breakthrough in battery technology reduces costs by 60%, accelerating electric vehicle adoption. By 2027, major automakers discontinue ICE production as consumers rapidly shift preferences...'"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-sm text-gray-500 mt-1">
                  {formData.content.length} characters
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={editingNarrative ? handleUpdateNarrative : handleAddNarrative}
                  disabled={!formData.title || !formData.content}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  {editingNarrative ? 'Update' : 'Add'} Narrative
                </button>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingNarrative(null);
                    setFormData({ title: '', content: '', archetype: '', probability: 25 });
                  }}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Narratives List */}
        <div className="space-y-4">
          {scenario.narratives?.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-lg mb-2">No scenario narratives created yet</p>
              <p className="text-sm">Add your first narrative to begin developing your scenarios</p>
            </div>
          ) : (
            scenario.narratives?.map((narrative) => (
              <div key={narrative.id} className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <h3 className="text-lg font-semibold text-gray-900 mr-3">{narrative.title}</h3>
                      {narrative.archetype && (
                        <span className={`px-2 py-1 text-xs rounded-full ${getArchetypeColor(narrative.archetype)}`}>
                          {narrative.archetype}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center text-sm text-gray-500 mb-3">
                      <span>Probability: {narrative.probability}%</span>
                      <span className="mx-2">•</span>
                      <span>{narrative.content.length} characters</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-1">
                    <button
                      onClick={() => handleEditNarrative(narrative)}
                      className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteNarrative(narrative.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="prose prose-sm max-w-none">
                  <div className="text-gray-700 whitespace-pre-line leading-relaxed">
                    {narrative.content}
                  </div>
                </div>

                {/* Probability visualization */}
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-1">
                    <span>Probability Assessment</span>
                    <span>{narrative.probability}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${narrative.probability}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Summary Statistics */}
        {scenario.narratives && scenario.narratives.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">Narrative Summary</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Total Narratives:</span>
                <span className="ml-2 font-medium">{scenario.narratives.length}</span>
              </div>
              <div>
                <span className="text-gray-500">Avg. Probability:</span>
                <span className="ml-2 font-medium">
                  {Math.round(scenario.narratives.reduce((sum, n) => sum + n.probability, 0) / scenario.narratives.length)}%
                </span>
              </div>
              <div>
                <span className="text-gray-500">Total Words:</span>
                <span className="ml-2 font-medium">
                  {scenario.narratives.reduce((sum, n) => sum + n.content.split(' ').length, 0)}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NarrativeDevelopment;