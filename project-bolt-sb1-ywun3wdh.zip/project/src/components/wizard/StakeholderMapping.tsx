import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Users, Info } from 'lucide-react';
import { Scenario, Stakeholder } from '../../context/ScenarioContext';

interface StakeholderMappingProps {
  scenario: Partial<Scenario>;
  setScenario: (scenario: Partial<Scenario>) => void;
}

const StakeholderMapping: React.FC<StakeholderMappingProps> = ({ scenario, setScenario }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingStakeholder, setEditingStakeholder] = useState<Stakeholder | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    influence: 5,
    interest: 5,
    category: 'primary' as 'primary' | 'secondary' | 'key'
  });

  const handleAddStakeholder = () => {
    const newStakeholder: Stakeholder = {
      id: `stakeholder-${Date.now()}`,
      ...formData
    };

    setScenario({
      ...scenario,
      stakeholders: [...(scenario.stakeholders || []), newStakeholder]
    });

    setFormData({ name: '', role: '', influence: 5, interest: 5, category: 'primary' });
    setShowAddForm(false);
  };

  const handleEditStakeholder = (stakeholder: Stakeholder) => {
    setEditingStakeholder(stakeholder);
    setFormData({
      name: stakeholder.name,
      role: stakeholder.role,
      influence: stakeholder.influence,
      interest: stakeholder.interest,
      category: stakeholder.category
    });
    setShowAddForm(true);
  };

  const handleUpdateStakeholder = () => {
    if (!editingStakeholder) return;

    const updatedStakeholders = scenario.stakeholders?.map(s =>
      s.id === editingStakeholder.id ? { ...s, ...formData } : s
    ) || [];

    setScenario({
      ...scenario,
      stakeholders: updatedStakeholders
    });

    setFormData({ name: '', role: '', influence: 5, interest: 5, category: 'primary' });
    setShowAddForm(false);
    setEditingStakeholder(null);
  };

  const handleDeleteStakeholder = (id: string) => {
    setScenario({
      ...scenario,
      stakeholders: scenario.stakeholders?.filter(s => s.id !== id) || []
    });
  };

  const getStakeholderPosition = (stakeholder: Stakeholder) => {
    return {
      x: (stakeholder.influence / 10) * 100,
      y: 100 - (stakeholder.interest / 10) * 100
    };
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'primary': return 'bg-blue-500';
      case 'secondary': return 'bg-green-500';
      case 'key': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Stakeholder Mapping</h2>
        <p className="text-gray-600">
          Identify and analyze key stakeholders who influence or are affected by the scenarios. 
          Map them based on their level of influence and interest.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-blue-900 mb-1">Stakeholder Analysis Framework</h3>
            <p className="text-sm text-blue-700">
              Consider influence (ability to affect outcomes) and interest (level of concern) for each stakeholder. 
              Primary stakeholders are directly affected, secondary are indirectly affected, and key stakeholders 
              have significant decision-making power.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Stakeholder List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Stakeholders</h3>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Stakeholder
            </button>
          </div>

          {/* Add/Edit Form */}
          {showAddForm && (
            <div className="bg-gray-50 rounded-lg p-4 mb-4 border border-gray-200">
              <h4 className="font-medium text-gray-900 mb-3">
                {editingStakeholder ? 'Edit Stakeholder' : 'Add New Stakeholder'}
              </h4>
              
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Stakeholder name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                  <input
                    type="text"
                    placeholder="Role/Position"
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Influence (1-10)</label>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={formData.influence}
                      onChange={(e) => setFormData({ ...formData, influence: parseInt(e.target.value) })}
                      className="w-full"
                    />
                    <span className="text-xs text-gray-500">{formData.influence}</span>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Interest (1-10)</label>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={formData.interest}
                      onChange={(e) => setFormData({ ...formData, interest: parseInt(e.target.value) })}
                      className="w-full"
                    />
                    <span className="text-xs text-gray-500">{formData.interest}</span>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Category</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                      className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="primary">Primary</option>
                      <option value="secondary">Secondary</option>
                      <option value="key">Key</option>
                    </select>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={editingStakeholder ? handleUpdateStakeholder : handleAddStakeholder}
                    disabled={!formData.name || !formData.role}
                    className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
                  >
                    {editingStakeholder ? 'Update' : 'Add'} Stakeholder
                  </button>
                  <button
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingStakeholder(null);
                      setFormData({ name: '', role: '', influence: 5, interest: 5, category: 'primary' });
                    }}
                    className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Stakeholder List */}
          <div className="space-y-2">
            {scenario.stakeholders?.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p>No stakeholders added yet</p>
              </div>
            ) : (
              scenario.stakeholders?.map((stakeholder) => (
                <div key={stakeholder.id} className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${getCategoryColor(stakeholder.category)}`}></div>
                    <div>
                      <h4 className="font-medium text-gray-900 text-sm">{stakeholder.name}</h4>
                      <p className="text-xs text-gray-500">{stakeholder.role}</p>
                      <p className="text-xs text-gray-400">
                        Influence: {stakeholder.influence}/10 • Interest: {stakeholder.interest}/10
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => handleEditStakeholder(stakeholder)}
                      className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteStakeholder(stakeholder.id)}
                      className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Stakeholder Map */}
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Influence-Interest Matrix</h3>
          
          <div className="relative bg-white border border-gray-200 rounded-lg" style={{ height: '400px' }}>
            {/* Grid lines and labels */}
            <div className="absolute inset-0 p-4">
              {/* Y-axis label */}
              <div className="absolute left-2 top-1/2 transform -rotate-90 text-sm font-medium text-gray-600 origin-center">
                Interest Level
              </div>
              
              {/* X-axis label */}
              <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-sm font-medium text-gray-600">
                Influence Level
              </div>

              {/* Quadrant labels */}
              <div className="absolute top-4 left-16 text-xs text-gray-500">High Interest, Low Influence</div>
              <div className="absolute top-4 right-4 text-xs text-gray-500">High Interest, High Influence</div>
              <div className="absolute bottom-8 left-16 text-xs text-gray-500">Low Interest, Low Influence</div>
              <div className="absolute bottom-8 right-4 text-xs text-gray-500">Low Interest, High Influence</div>

              {/* Grid */}
              <svg className="absolute inset-4 w-full h-full" style={{ width: 'calc(100% - 2rem)', height: 'calc(100% - 2rem)' }}>
                <defs>
                  <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#f3f4f6" strokeWidth="1"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
                <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#e5e7eb" strokeWidth="2" />
                <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#e5e7eb" strokeWidth="2" />
              </svg>

              {/* Stakeholder dots */}
              {scenario.stakeholders?.map((stakeholder) => {
                const position = getStakeholderPosition(stakeholder);
                return (
                  <div
                    key={stakeholder.id}
                    className={`absolute w-3 h-3 rounded-full transform -translate-x-1/2 -translate-y-1/2 ${getCategoryColor(stakeholder.category)} border-2 border-white shadow-sm`}
                    style={{
                      left: `calc(1rem + ${position.x}% * (100% - 2rem) / 100)`,
                      top: `calc(1rem + ${position.y}% * (100% - 2rem) / 100)`
                    }}
                    title={`${stakeholder.name} - ${stakeholder.role}`}
                  />
                );
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="mt-4 flex flex-wrap gap-4 text-sm">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
              <span>Primary</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
              <span>Secondary</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
              <span>Key</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StakeholderMapping;