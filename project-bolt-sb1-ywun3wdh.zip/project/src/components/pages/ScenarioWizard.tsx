import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Save, Check } from 'lucide-react';
import { useScenarios, Scenario } from '../../context/ScenarioContext';
import ContextAnalysis from '../wizard/ContextAnalysis';
import StakeholderMapping from '../wizard/StakeholderMapping';
import UncertaintyAxes from '../wizard/UncertaintyAxes';
import NarrativeDevelopment from '../wizard/NarrativeDevelopment';
import StrategicImplications from '../wizard/StrategicImplications';

const ScenarioWizard: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { state, dispatch } = useScenarios();
  
  const [currentStep, setCurrentStep] = useState(0);
  const [scenario, setScenario] = useState<Partial<Scenario>>({
    name: '',
    description: '',
    methodology: 'ramirez-ravetz',
    status: 'draft',
    context: {
      title: '',
      description: '',
      timeHorizon: '',
      geographicScope: '',
      keyQuestion: ''
    },
    stakeholders: [],
    uncertaintyAxes: [],
    narratives: [],
    strategicImplications: {
      opportunities: [],
      threats: [],
      recommendations: []
    },
    collaborators: [],
    version: 1,
    changeLog: []
  });

  const steps = [
    { id: 'context', title: 'Context Analysis', description: 'Define the scope and critical uncertainties' },
    { id: 'stakeholders', title: 'Stakeholder Mapping', description: 'Identify and analyze key stakeholders' },
    { id: 'axes', title: 'Uncertainty Axes', description: 'Construct uncertainty dimensions' },
    { id: 'narratives', title: 'Scenario Narratives', description: 'Develop plausible scenario stories' },
    { id: 'implications', title: 'Strategic Implications', description: 'Analyze implications and strategies' }
  ];

  useEffect(() => {
    if (id && state.scenarios.length > 0) {
      const existingScenario = state.scenarios.find(s => s.id === id);
      if (existingScenario) {
        setScenario(existingScenario);
      }
    }
  }, [id, state.scenarios]);

  const handleSave = async () => {
    const now = new Date();
    const scenarioData: Scenario = {
      ...scenario,
      id: scenario.id || `scenario-${Date.now()}`,
      createdAt: scenario.createdAt || now,
      updatedAt: now,
      changeLog: [
        ...scenario.changeLog || [],
        {
          date: now,
          author: 'Current User',
          changes: id ? 'Scenario updated' : 'Scenario created'
        }
      ]
    } as Scenario;

    if (id) {
      dispatch({ type: 'UPDATE_SCENARIO', payload: scenarioData });
    } else {
      dispatch({ type: 'ADD_SCENARIO', payload: scenarioData });
    }

    navigate('/scenarios');
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return <ContextAnalysis scenario={scenario} setScenario={setScenario} />;
      case 1:
        return <StakeholderMapping scenario={scenario} setScenario={setScenario} />;
      case 2:
        return <UncertaintyAxes scenario={scenario} setScenario={setScenario} />;
      case 3:
        return <NarrativeDevelopment scenario={scenario} setScenario={setScenario} />;
      case 4:
        return <StrategicImplications scenario={scenario} setScenario={setScenario} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/scenarios')}
                className="mr-4 p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {id ? 'Edit Scenario' : 'Create New Scenario'}
                </h1>
                <p className="text-sm text-gray-500">Ramirez-Ravetz Methodology</p>
              </div>
            </div>
            
            <button
              onClick={handleSave}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Scenario
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Step Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Progress</h2>
              <nav className="space-y-3">
                {steps.map((step, index) => (
                  <button
                    key={step.id}
                    onClick={() => setCurrentStep(index)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      index === currentStep
                        ? 'bg-blue-50 border border-blue-200'
                        : index < currentStep
                        ? 'bg-green-50 border border-green-200'
                        : 'bg-gray-50 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                        index === currentStep
                          ? 'bg-blue-600 text-white'
                          : index < currentStep
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-300 text-gray-600'
                      }`}>
                        {index < currentStep ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <span className="text-xs font-medium">{index + 1}</span>
                        )}
                      </div>
                      <div>
                        <p className={`text-sm font-medium ${
                          index === currentStep ? 'text-blue-900' : 
                          index < currentStep ? 'text-green-900' : 'text-gray-700'
                        }`}>
                          {step.title}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{step.description}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Step Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              {renderStepContent()}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-6">
              <button
                onClick={handlePrevious}
                disabled={currentStep === 0}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  currentStep === 0
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </button>

              <button
                onClick={handleNext}
                disabled={currentStep === steps.length - 1}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  currentStep === steps.length - 1
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScenarioWizard;