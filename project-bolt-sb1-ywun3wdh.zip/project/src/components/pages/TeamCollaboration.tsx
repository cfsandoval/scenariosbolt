import React, { useState } from 'react';
import { Users, MessageSquare, Clock, UserPlus, Settings, Send } from 'lucide-react';
import { useTeam } from '../../context/TeamContext';

const TeamCollaboration: React.FC = () => {
  const { state, dispatch } = useTeam();
  const [newComment, setNewComment] = useState('');
  const [selectedSection, setSelectedSection] = useState('general');

  const handleAddComment = () => {
    if (!newComment.trim()) return;

    const comment = {
      id: `comment-${Date.now()}`,
      authorId: '1', // Current user
      content: newComment.trim(),
      timestamp: new Date(),
      scenarioId: 'current-scenario',
      section: selectedSection
    };

    dispatch({ type: 'ADD_COMMENT', payload: comment });
    setNewComment('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-400';
      case 'away': return 'bg-yellow-400';
      default: return 'bg-gray-400';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-800';
      case 'facilitator': return 'bg-blue-100 text-blue-800';
      case 'contributor': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCommentsForSection = (section: string) => {
    return state.comments.filter(comment => comment.section === section);
  };

  const getAuthorName = (authorId: string) => {
    const author = state.members.find(m => m.id === authorId);
    return author?.name || 'Unknown User';
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Team Collaboration</h1>
          <p className="text-gray-600 mt-1">Collaborate with your team on scenario development</p>
        </div>
        <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Members
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Team Members */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Team Members</h2>
              <Users className="w-5 h-5 text-gray-400" />
            </div>

            <div className="space-y-4">
              {state.members.map((member) => (
                <div key={member.id} className="flex items-center space-x-3">
                  <div className="relative">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-teal-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 ${getStatusColor(member.status)} border-2 border-white rounded-full`}></div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-900 truncate">{member.name}</p>
                      <span className={`px-1.5 py-0.5 text-xs rounded ${getRoleColor(member.role)}`}>
                        {member.role}
                      </span>
                    </div>
                    <div className="flex items-center text-xs text-gray-500">
                      <Clock className="w-3 h-3 mr-1" />
                      {member.status === 'online' ? 'Active now' : 
                       new Date(member.lastActive).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Online Status */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="flex items-center text-sm text-gray-600">
                <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                {state.members.filter(m => m.status === 'online').length} online
              </div>
            </div>
          </div>
        </div>

        {/* Collaboration Space */}
        <div className="lg:col-span-2 space-y-6">
          {/* Discussion Threads */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="border-b border-gray-200 p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Discussion</h2>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="px-3 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="general">General</option>
                  <option value="context">Context Analysis</option>
                  <option value="stakeholders">Stakeholders</option>
                  <option value="uncertainties">Uncertainty Axes</option>
                  <option value="narratives">Narratives</option>
                  <option value="implications">Strategic Implications</option>
                </select>
              </div>
            </div>

            <div className="p-4">
              {/* Comments for selected section */}
              <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                {getCommentsForSection(selectedSection).length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                    <p>No comments yet for {selectedSection}</p>
                    <p className="text-sm">Start the discussion!</p>
                  </div>
                ) : (
                  getCommentsForSection(selectedSection).map((comment) => (
                    <div key={comment.id} className="flex space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-medium text-xs">
                          {getAuthorName(comment.authorId).split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-gray-900">
                              {getAuthorName(comment.authorId)}
                            </span>
                            <span className="text-xs text-gray-500">
                              {comment.timestamp.toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700">{comment.content}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Add Comment */}
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-medium text-xs">SC</span>
                </div>
                <div className="flex-1">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder={`Add a comment to ${selectedSection}...`}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      onKeyPress={(e) => e.key === 'Enter' && handleAddComment()}
                    />
                    <button
                      onClick={handleAddComment}
                      disabled={!newComment.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
            
            <div className="space-y-4">
              {[
                {
                  id: 1,
                  type: 'comment',
                  user: 'Sarah Chen',
                  action: 'commented on Context Analysis',
                  time: '2 minutes ago'
                },
                {
                  id: 2,
                  type: 'edit',
                  user: 'Marcus Johnson',
                  action: 'updated stakeholder mapping',
                  time: '15 minutes ago'
                },
                {
                  id: 3,
                  type: 'join',
                  user: 'Elena Rodriguez',
                  action: 'joined the collaboration',
                  time: '1 hour ago'
                }
              ].map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">{activity.user}</span> {activity.action}
                    </p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Collaboration Settings */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Collaboration Settings</h2>
              <Settings className="w-5 h-5 text-gray-400" />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Real-time notifications</h3>
                  <p className="text-xs text-gray-500">Get notified when team members make changes</p>
                </div>
                <input type="checkbox" className="toggle" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Auto-save changes</h3>
                  <p className="text-xs text-gray-500">Automatically save edits as you work</p>
                </div>
                <input type="checkbox" className="toggle" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Version control</h3>
                  <p className="text-xs text-gray-500">Track all changes with version history</p>
                </div>
                <input type="checkbox" className="toggle" defaultChecked />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamCollaboration;