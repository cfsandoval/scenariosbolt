import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Plus, Eye, Calendar, Filter } from 'lucide-react';

interface WeakSignal {
  id: string;
  title: string;
  description: string;
  source: string;
  category: string;
  relevance: number;
  confidence: number;
  trend: 'up' | 'down' | 'stable';
  detectedAt: Date;
  relatedScenarios: string[];
}

const MonitoringDashboard: React.FC = () => {
  const [signals] = useState<WeakSignal[]>([
    {
      id: '1',
      title: 'Increasing EV Adoption in Urban Areas',
      description: 'Electric vehicle sales in major cities show 40% year-over-year growth, driven by charging infrastructure expansion and policy incentives.',
      source: 'Industry Reports',
      category: 'Technology',
      relevance: 8,
      confidence: 7,
      trend: 'up',
      detectedAt: new Date(Date.now() - 86400000 * 2),
      relatedScenarios: ['scenario-1', 'scenario-2']
    },
    {
      id: '2',
      title: 'Remote Work Policy Standardization',
      description: 'Major corporations are establishing permanent remote work policies, indicating long-term structural changes in work patterns.',
      source: 'HR Analytics',
      category: 'Social',
      relevance: 6,
      confidence: 8,
      trend: 'up',
      detectedAt: new Date(Date.now() - 86400000 * 5),
      relatedScenarios: ['scenario-3']
    },
    {
      id: '3',
      title: 'Decline in Traditional Retail Footfall',
      description: 'Physical retail locations continue to see decreased foot traffic as e-commerce adoption accelerates post-pandemic.',
      source: 'Retail Analytics',
      category: 'Economic',
      relevance: 7,
      confidence: 9,
      trend: 'down',
      detectedAt: new Date(Date.now() - 86400000 * 3),
      relatedScenarios: ['scenario-1']
    },
    {
      id: '4',
      title: 'AI Regulation Framework Development',
      description: 'Multiple governments are drafting comprehensive AI governance frameworks, suggesting imminent regulatory changes.',
      source: 'Policy Watch',
      category: 'Political',
      relevance: 9,
      confidence: 6,
      trend: 'up',
      detectedAt: new Date(Date.now() - 86400000 * 1),
      relatedScenarios: ['scenario-2', 'scenario-3']
    }
  ]);

  const [categoryFilter, setCategoryFilter] = useState('all');
  const [relevanceFilter, setRelevanceFilter] = useState(0);

  const filteredSignals = signals.filter(signal => {
    const matchesCategory = categoryFilter === 'all' || signal.category === categoryFilter;
    const matchesRelevance = signal.relevance >= relevanceFilter;
    return matchesCategory && matchesRelevance;
  });

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <div className="w-4 h-4 bg-gray-400 rounded-full" />;
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Technology': 'bg-blue-100 text-blue-800',
      'Social': 'bg-green-100 text-green-800',
      'Economic': 'bg-yellow-100 text-yellow-800',
      'Political': 'bg-purple-100 text-purple-800',
      'Environmental': 'bg-teal-100 text-teal-800'
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  const getRelevanceColor = (relevance: number) => {
    if (relevance >= 8) return 'text-red-600 bg-red-50';
    if (relevance >= 6) return 'text-yellow-600 bg-yellow-50';
    return 'text-green-600 bg-green-50';
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Monitoring Dashboard</h1>
          <p className="text-gray-600 mt-1">Track weak signals and emerging trends relevant to your scenarios</p>
        </div>
        <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-4 h-4 mr-2" />
          Add Signal Source
        </button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg mr-4">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Active Signals</p>
              <p className="text-2xl font-bold text-gray-900">{signals.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-red-100 rounded-lg mr-4">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">High Priority</p>
              <p className="text-2xl font-bold text-gray-900">
                {signals.filter(s => s.relevance >= 8).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg mr-4">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Emerging Trends</p>
              <p className="text-2xl font-bold text-gray-900">
                {signals.filter(s => s.trend === 'up').length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-lg mr-4">
              <Eye className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Sources</p>
              <p className="text-2xl font-bold text-gray-900">
                {new Set(signals.map(s => s.source)).size}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <Filter className="w-4 h-4 text-gray-400 mr-2" />
            <label className="text-sm font-medium text-gray-700 mr-2">Category:</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            >
              <option value="all">All Categories</option>
              <option value="Technology">Technology</option>
              <option value="Social">Social</option>
              <option value="Economic">Economic</option>
              <option value="Political">Political</option>
              <option value="Environmental">Environmental</option>
            </select>
          </div>

          <div className="flex items-center">
            <label className="text-sm font-medium text-gray-700 mr-2">Min Relevance:</label>
            <input
              type="range"
              min="0"
              max="10"
              value={relevanceFilter}
              onChange={(e) => setRelevanceFilter(parseInt(e.target.value))}
              className="w-20"
            />
            <span className="ml-2 text-sm text-gray-600">{relevanceFilter}+</span>
          </div>

          <div className="text-sm text-gray-500">
            {filteredSignals.length} of {signals.length} signals
          </div>
        </div>
      </div>

      {/* Signals Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredSignals.map((signal) => (
          <div key={signal.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <h3 className="text-lg font-semibold text-gray-900 mr-3">{signal.title}</h3>
                  {getTrendIcon(signal.trend)}
                </div>
                <p className="text-sm text-gray-600 mb-3">{signal.description}</p>
              </div>
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 text-xs rounded-full ${getCategoryColor(signal.category)}`}>
                  {signal.category}
                </span>
                <span className="text-xs text-gray-500">
                  {signal.source}
                </span>
              </div>
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="w-3 h-3 mr-1" />
                {signal.detectedAt.toLocaleDateString()}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-xs font-medium text-gray-500">Relevance</label>
                <div className="flex items-center mt-1">
                  <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${signal.relevance * 10}%` }}
                    ></div>
                  </div>
                  <span className={`text-xs font-medium px-1.5 py-0.5 rounded ${getRelevanceColor(signal.relevance)}`}>
                    {signal.relevance}/10
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-500">Confidence</label>
                <div className="flex items-center mt-1">
                  <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${signal.confidence * 10}%` }}
                    ></div>
                  </div>
                  <span className="text-xs font-medium text-gray-700">
                    {signal.confidence}/10
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-xs font-medium text-gray-500">Related Scenarios</label>
                  <div className="text-xs text-gray-700 mt-1">
                    {signal.relatedScenarios.length} scenarios affected
                  </div>
                </div>
                <button className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors">
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredSignals.length === 0 && (
        <div className="text-center py-12">
          <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No signals match your filters</h3>
          <p className="text-gray-500">Try adjusting your category or relevance filters</p>
        </div>
      )}
    </div>
  );
};

export default MonitoringDashboard;