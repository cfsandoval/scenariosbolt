import React, { useState } from 'react';
import { BarChart3, Download, Eye, EyeOff } from 'lucide-react';
import { useScenarios } from '../../context/ScenarioContext';

const ScenarioComparison: React.FC = () => {
  const { state } = useScenarios();
  const [selectedScenarios, setSelectedScenarios] = useState<string[]>([]);
  const [comparisonView, setComparisonView] = useState<'overview' | 'stakeholders' | 'narratives' | 'implications'>('overview');

  const toggleScenarioSelection = (scenarioId: string) => {
    if (selectedScenarios.includes(scenarioId)) {
      setSelectedScenarios(selectedScenarios.filter(id => id !== scenarioId));
    } else if (selectedScenarios.length < 4) {
      setSelectedScenarios([...selectedScenarios, scenarioId]);
    }
  };

  const getSelectedScenarioData = () => {
    return state.scenarios.filter(s => selectedScenarios.includes(s.id));
  };

  const exportComparison = () => {
    const selectedData = getSelectedScenarioData();
    const comparisonData = {
      exported_at: new Date().toISOString(),
      scenarios: selectedData.map(scenario => ({
        id: scenario.id,
        name: scenario.name,
        description: scenario.description,
        status: scenario.status,
        methodology: scenario.methodology,
        stakeholders_count: scenario.stakeholders?.length || 0,
        uncertainty_axes_count: scenario.uncertaintyAxes?.length || 0,
        narratives_count: scenario.narratives?.length || 0,
        opportunities_count: scenario.strategicImplications?.opportunities?.length || 0,
        threats_count: scenario.strategicImplications?.threats?.length || 0,
        recommendations_count: scenario.strategicImplications?.recommendations?.length || 0
      }))
    };

    const blob = new Blob([JSON.stringify(comparisonData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `scenario-comparison-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'review': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const selectedData = getSelectedScenarioData();

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Scenario Comparison</h1>
          <p className="text-gray-600 mt-1">Compare scenarios side by side to identify patterns and insights</p>
        </div>
        {selectedScenarios.length > 0 && (
          <button
            onClick={exportComparison}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Comparison
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Scenario Selection */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sticky top-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Scenarios</h2>
            <p className="text-sm text-gray-600 mb-4">Choose up to 4 scenarios to compare</p>
            
            <div className="space-y-2">
              {state.scenarios.map((scenario) => (
                <div
                  key={scenario.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedScenarios.includes(scenario.id)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                  onClick={() => toggleScenarioSelection(scenario.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-sm text-gray-900">{scenario.name}</h3>
                      <div className="flex items-center mt-1 space-x-2">
                        <span className={`px-1.5 py-0.5 text-xs rounded ${getStatusColor(scenario.status)}`}>
                          {scenario.status}
                        </span>
                      </div>
                    </div>
                    {selectedScenarios.includes(scenario.id) ? (
                      <Eye className="w-4 h-4 text-blue-600" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-gray-400" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            {selectedScenarios.length === 0 && state.scenarios.length === 0 && (
              <div className="text-center py-8">
                <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500">No scenarios available for comparison</p>
              </div>
            )}
            
            {selectedScenarios.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  {selectedScenarios.length} of 4 scenarios selected
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Comparison View */}
        <div className="lg:col-span-3">
          {selectedScenarios.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
              <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Select scenarios to compare</h3>
              <p className="text-gray-500">Choose scenarios from the left panel to begin your comparison analysis</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Comparison Navigation */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="border-b border-gray-200">
                  <nav className="-mb-px flex space-x-8 px-6">
                    {[
                      { id: 'overview', name: 'Overview' },
                      { id: 'stakeholders', name: 'Stakeholders' },
                      { id: 'narratives', name: 'Narratives' },
                      { id: 'implications', name: 'Strategic Implications' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setComparisonView(tab.id as any)}
                        className={`py-4 px-1 border-b-2 font-medium text-sm ${
                          comparisonView === tab.id
                            ? 'border-blue-500 text-blue-600'
                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }`}
                      >
                        {tab.name}
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="p-6">
                  {comparisonView === 'overview' && (
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-gray-900">Scenario Overview</h3>
                      
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Attribute
                              </th>
                              {selectedData.map((scenario) => (
                                <th key={scenario.id} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  {scenario.name}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Status</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(scenario.status)}`}>
                                    {scenario.status.replace('-', ' ')}
                                  </span>
                                </td>
                              ))}
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Methodology</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {scenario.methodology.toUpperCase()}
                                </td>
                              ))}
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Stakeholders</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {scenario.stakeholders?.length || 0}
                                </td>
                              ))}
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Uncertainty Axes</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {scenario.uncertaintyAxes?.length || 0}
                                </td>
                              ))}
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Narratives</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {scenario.narratives?.length || 0}
                                </td>
                              ))}
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Last Updated</td>
                              {selectedData.map((scenario) => (
                                <td key={scenario.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {new Date(scenario.updatedAt).toLocaleDateString()}
                                </td>
                              ))}
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {comparisonView === 'stakeholders' && (
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-gray-900">Stakeholder Analysis</h3>
                      
                      <div className="grid grid-cols-1 gap-6">
                        {selectedData.map((scenario) => (
                          <div key={scenario.id} className="border border-gray-200 rounded-lg p-4">
                            <h4 className="font-medium text-gray-900 mb-3">{scenario.name}</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                              {scenario.stakeholders?.map((stakeholder) => (
                                <div key={stakeholder.id} className="bg-gray-50 p-2 rounded text-sm">
                                  <div className="font-medium">{stakeholder.name}</div>
                                  <div className="text-gray-600 text-xs">{stakeholder.role}</div>
                                  <div className="text-gray-500 text-xs">
                                    I: {stakeholder.influence}/10, R: {stakeholder.interest}/10
                                  </div>
                                </div>
                              )) || <p className="text-gray-500 text-sm">No stakeholders defined</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {comparisonView === 'narratives' && (
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-gray-900">Scenario Narratives</h3>
                      
                      <div className="space-y-6">
                        {selectedData.map((scenario) => (
                          <div key={scenario.id} className="border border-gray-200 rounded-lg p-6">
                            <h4 className="font-medium text-gray-900 mb-4">{scenario.name}</h4>
                            <div className="space-y-4">
                              {scenario.narratives?.map((narrative) => (
                                <div key={narrative.id} className="bg-gray-50 p-4 rounded-lg">
                                  <div className="flex items-center justify-between mb-2">
                                    <h5 className="font-medium text-gray-900">{narrative.title}</h5>
                                    <span className="text-sm text-gray-500">{narrative.probability}% probability</span>
                                  </div>
                                  <p className="text-sm text-gray-700 line-clamp-3">{narrative.content}</p>
                                  {narrative.archetype && (
                                    <span className="inline-block mt-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                                      {narrative.archetype}
                                    </span>
                                  )}
                                </div>
                              )) || <p className="text-gray-500">No narratives developed</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {comparisonView === 'implications' && (
                    <div className="space-y-6">
                      <h3 className="text-lg font-semibold text-gray-900">Strategic Implications</h3>
                      
                      <div className="space-y-6">
                        {selectedData.map((scenario) => (
                          <div key={scenario.id} className="border border-gray-200 rounded-lg p-6">
                            <h4 className="font-medium text-gray-900 mb-4">{scenario.name}</h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                              <div>
                                <h5 className="font-medium text-green-700 mb-2">Opportunities</h5>
                                <div className="space-y-1">
                                  {scenario.strategicImplications?.opportunities?.map((opp, idx) => (
                                    <div key={idx} className="text-sm bg-green-50 p-2 rounded text-green-800">
                                      {opp}
                                    </div>
                                  )) || <p className="text-gray-500 text-sm">None identified</p>}
                                </div>
                              </div>

                              <div>
                                <h5 className="font-medium text-red-700 mb-2">Threats</h5>
                                <div className="space-y-1">
                                  {scenario.strategicImplications?.threats?.map((threat, idx) => (
                                    <div key={idx} className="text-sm bg-red-50 p-2 rounded text-red-800">
                                      {threat}
                                    </div>
                                  )) || <p className="text-gray-500 text-sm">None identified</p>}
                                </div>
                              </div>

                              <div>
                                <h5 className="font-medium text-blue-700 mb-2">Recommendations</h5>
                                <div className="space-y-1">
                                  {scenario.strategicImplications?.recommendations?.map((rec, idx) => (
                                    <div key={idx} className="text-sm bg-blue-50 p-2 rounded text-blue-800">
                                      {rec}
                                    </div>
                                  )) || <p className="text-gray-500 text-sm">None provided</p>}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScenarioComparison;