import React from 'react';
import { Link } from 'react-router-dom';
import { 
  FileText, 
  Plus, 
  TrendingUp, 
  Users, 
  Clock, 
  AlertTriangle,
  BarChart3,
  CheckCircle
} from 'lucide-react';
import { useScenarios } from '../../context/ScenarioContext';
import { useTeam } from '../../context/TeamContext';

const Dashboard: React.FC = () => {
  const { state: scenarioState } = useScenarios();
  const { state: teamState } = useTeam();

  const stats = [
    {
      name: 'Active Scenarios',
      value: scenarioState.scenarios.filter(s => s.status !== 'completed').length,
      icon: FileText,
      color: 'text-blue-600 bg-blue-100'
    },
    {
      name: 'Team Members',
      value: teamState.members.length,
      icon: Users,
      color: 'text-green-600 bg-green-100'
    },
    {
      name: 'Completed Scenarios',
      value: scenarioState.scenarios.filter(s => s.status === 'completed').length,
      icon: CheckCircle,
      color: 'text-purple-600 bg-purple-100'
    },
    {
      name: 'Monitoring Signals',
      value: 12,
      icon: TrendingUp,
      color: 'text-orange-600 bg-orange-100'
    }
  ];

  const recentActivity = [
    {
      id: 1,
      type: 'scenario_created',
      description: 'New scenario "Climate Change Impact 2030" created',
      time: '2 hours ago',
      author: 'Sarah Chen'
    },
    {
      id: 2,
      type: 'collaboration',
      description: 'Marcus Johnson added stakeholder analysis',
      time: '4 hours ago',
      author: 'Marcus Johnson'
    },
    {
      id: 3,
      type: 'monitoring',
      description: 'Weak signal detected: Renewable energy adoption',
      time: '6 hours ago',
      author: 'System'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Welcome to ScenarioLab</h1>
        <p className="text-blue-100 mb-4">
          Your platform for strategic foresight and scenario planning using the Ramirez-Ravetz methodology
        </p>
        <Link
          to="/create-scenario"
          className="inline-flex items-center px-4 py-2 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New Scenario
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg ${stat.color} mr-4`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Scenarios */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Recent Scenarios</h2>
              <Link
                to="/scenarios"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                View all
              </Link>
            </div>
          </div>
          
          <div className="p-6">
            {scenarioState.scenarios.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No scenarios created yet</p>
                <Link
                  to="/create-scenario"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Scenario
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {scenarioState.scenarios.slice(0, 3).map((scenario) => (
                  <div key={scenario.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{scenario.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">{scenario.description}</p>
                      <div className="flex items-center mt-2 space-x-4">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          scenario.status === 'completed' ? 'bg-green-100 text-green-800' :
                          scenario.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                          scenario.status === 'review' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {scenario.status}
                        </span>
                        <span className="text-xs text-gray-500">
                          {scenario.methodology.toUpperCase()}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">
                        {new Date(scenario.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Activity Feed */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Activity</h2>
          </div>
          
          <div className="p-6">
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.description}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {activity.author} • {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link
            to="/create-scenario"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Plus className="w-8 h-8 text-blue-600 mr-3" />
            <div>
              <h3 className="font-medium text-gray-900">Create Scenario</h3>
              <p className="text-sm text-gray-500">Start a new scenario planning session</p>
            </div>
          </Link>
          
          <Link
            to="/compare"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <BarChart3 className="w-8 h-8 text-green-600 mr-3" />
            <div>
              <h3 className="font-medium text-gray-900">Compare Scenarios</h3>
              <p className="text-sm text-gray-500">Analyze multiple scenarios side by side</p>
            </div>
          </Link>
          
          <Link
            to="/monitoring"
            className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <TrendingUp className="w-8 h-8 text-orange-600 mr-3" />
            <div>
              <h3 className="font-medium text-gray-900">Monitor Signals</h3>
              <p className="text-sm text-gray-500">Track weak signals and indicators</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;