import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'facilitator' | 'contributor' | 'observer';
  avatar?: string;
  lastActive: Date;
  status: 'online' | 'offline' | 'away';
}

export interface Comment {
  id: string;
  authorId: string;
  content: string;
  timestamp: Date;
  scenarioId: string;
  section: string;
}

interface TeamState {
  members: TeamMember[];
  comments: Comment[];
  activeCollaborators: string[];
}

type TeamAction =
  | { type: 'SET_MEMBERS'; payload: TeamMember[] }
  | { type: 'ADD_MEMBER'; payload: TeamMember }
  | { type: 'UPDATE_MEMBER'; payload: TeamMember }
  | { type: 'ADD_COMMENT'; payload: Comment }
  | { type: 'SET_ACTIVE_COLLABORATORS'; payload: string[] };

const initialState: TeamState = {
  members: [
    {
      id: '1',
      name: 'Sarah Chen',
      email: 'sarah.chen@company.com',
      role: 'admin',
      lastActive: new Date(),
      status: 'online'
    },
    {
      id: '2',
      name: 'Marcus Johnson',
      email: 'marcus.j@company.com',
      role: 'facilitator',
      lastActive: new Date(Date.now() - 300000),
      status: 'away'
    },
    {
      id: '3',
      name: 'Elena Rodriguez',
      email: 'elena.r@company.com',
      role: 'contributor',
      lastActive: new Date(Date.now() - 600000),
      status: 'offline'
    }
  ],
  comments: [],
  activeCollaborators: ['1']
};

const teamReducer = (state: TeamState, action: TeamAction): TeamState => {
  switch (action.type) {
    case 'SET_MEMBERS':
      return { ...state, members: action.payload };
    case 'ADD_MEMBER':
      return { ...state, members: [...state.members, action.payload] };
    case 'UPDATE_MEMBER':
      return {
        ...state,
        members: state.members.map(m => m.id === action.payload.id ? action.payload : m)
      };
    case 'ADD_COMMENT':
      return { ...state, comments: [...state.comments, action.payload] };
    case 'SET_ACTIVE_COLLABORATORS':
      return { ...state, activeCollaborators: action.payload };
    default:
      return state;
  }
};

const TeamContext = createContext<{
  state: TeamState;
  dispatch: React.Dispatch<TeamAction>;
} | null>(null);

export const TeamProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(teamReducer, initialState);

  return (
    <TeamContext.Provider value={{ state, dispatch }}>
      {children}
    </TeamContext.Provider>
  );
};

export const useTeam = () => {
  const context = useContext(TeamContext);
  if (!context) {
    throw new Error('useTeam must be used within a TeamProvider');
  }
  return context;
};