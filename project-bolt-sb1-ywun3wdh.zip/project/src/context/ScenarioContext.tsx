import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface Stakeholder {
  id: string;
  name: string;
  role: string;
  influence: number;
  interest: number;
  category: 'primary' | 'secondary' | 'key';
}

export interface UncertaintyAxis {
  id: string;
  name: string;
  description: string;
  lowEnd: string;
  highEnd: string;
  impact: number;
  uncertainty: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  methodology: 'ramirez-ravetz' | 'shell' | 'delphi' | 'cla' | 'three-horizons';
  status: 'draft' | 'in-progress' | 'review' | 'completed';
  createdAt: Date;
  updatedAt: Date;
  context: {
    title: string;
    description: string;
    timeHorizon: string;
    geographicScope: string;
    keyQuestion: string;
  };
  stakeholders: Stakeholder[];
  uncertaintyAxes: UncertaintyAxis[];
  narratives: {
    id: string;
    title: string;
    content: string;
    archetype: string;
    probability: number;
  }[];
  strategicImplications: {
    opportunities: string[];
    threats: string[];
    recommendations: string[];
  };
  collaborators: string[];
  version: number;
  changeLog: {
    date: Date;
    author: string;
    changes: string;
  }[];
}

interface ScenarioState {
  scenarios: Scenario[];
  currentScenario: Scenario | null;
}

type ScenarioAction =
  | { type: 'SET_SCENARIOS'; payload: Scenario[] }
  | { type: 'ADD_SCENARIO'; payload: Scenario }
  | { type: 'UPDATE_SCENARIO'; payload: Scenario }
  | { type: 'DELETE_SCENARIO'; payload: string }
  | { type: 'SET_CURRENT_SCENARIO'; payload: Scenario | null };

const initialState: ScenarioState = {
  scenarios: [],
  currentScenario: null
};

const scenarioReducer = (state: ScenarioState, action: ScenarioAction): ScenarioState => {
  switch (action.type) {
    case 'SET_SCENARIOS':
      return { ...state, scenarios: action.payload };
    case 'ADD_SCENARIO':
      return { ...state, scenarios: [...state.scenarios, action.payload] };
    case 'UPDATE_SCENARIO':
      return {
        ...state,
        scenarios: state.scenarios.map(s => s.id === action.payload.id ? action.payload : s),
        currentScenario: state.currentScenario?.id === action.payload.id ? action.payload : state.currentScenario
      };
    case 'DELETE_SCENARIO':
      return {
        ...state,
        scenarios: state.scenarios.filter(s => s.id !== action.payload),
        currentScenario: state.currentScenario?.id === action.payload ? null : state.currentScenario
      };
    case 'SET_CURRENT_SCENARIO':
      return { ...state, currentScenario: action.payload };
    default:
      return state;
  }
};

const ScenarioContext = createContext<{
  state: ScenarioState;
  dispatch: React.Dispatch<ScenarioAction>;
} | null>(null);

export const ScenarioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(scenarioReducer, initialState);

  return (
    <ScenarioContext.Provider value={{ state, dispatch }}>
      {children}
    </ScenarioContext.Provider>
  );
};

export const useScenarios = () => {
  const context = useContext(ScenarioContext);
  if (!context) {
    throw new Error('useScenarios must be used within a ScenarioProvider');
  }
  return context;
};